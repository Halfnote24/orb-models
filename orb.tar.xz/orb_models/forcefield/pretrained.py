from functools import partial
from typing import cast, overload

import torch
from cached_path import cached_path

from orb_models.common.atoms.featurization import gaussian_basis_function
from orb_models.common.models.angular import SphericalHarmonics
from orb_models.common.models.gns import MoleculeGNS
from orb_models.common.models.graph_regressor import GraphHead
from orb_models.common.models.nn_util import ChargeSpinConditioner
from orb_models.common.models.rbf import BesselBasis
from orb_models.common.torch_utils import get_device
from orb_models.common.training.util import set_torch_precision
from orb_models.forcefield.forcefield_adapter import ForcefieldAtomsAdapter
from orb_models.forcefield.models.conservative_regressor import ConservativeForcefieldRegressor
from orb_models.forcefield.models.direct_regressor import DirectForcefieldRegressor
from orb_models.forcefield.models.forcefield_heads import (
    ConfidenceHead,
    EnergyHead,
    ForcefieldHead,
    ForceHead,
    StressHead,
)


def _should_compile(device: torch.device | str | int | None, compile: bool | None) -> bool:
    """Determine if the model should be compiled."""
    device = get_device(device)
    if compile is None:
        compile = device.type != "mps"
    assert not (device.type == "mps" and compile), "Model compilation is not supported on MPS."
    return compile


def load_model_for_inference(
    model: DirectForcefieldRegressor | ConservativeForcefieldRegressor,
    weights_path: str,
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
) -> DirectForcefieldRegressor | ConservativeForcefieldRegressor:
    """See `load_model` for details.

    This is kept here for backwards compatibility.
    """
    return load_model(
        model, weights_path, device, precision=precision, compile=compile, train=False
    )


@overload
def load_model(
    model: DirectForcefieldRegressor,
    weights_path: str,
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> DirectForcefieldRegressor: ...
@overload
def load_model(
    model: ConservativeForcefieldRegressor,
    weights_path: str,
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> ConservativeForcefieldRegressor: ...
def load_model(
    model: DirectForcefieldRegressor | ConservativeForcefieldRegressor,
    weights_path: str,
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> DirectForcefieldRegressor | ConservativeForcefieldRegressor:
    """Load a pretrained model from a local path or a wandb artifact.

    Args:
        model: The model to load the weights into.
        weights_path: The name of the weights file.
        device: Defaults to GPU if available, but specific CUDA devices can be specified via device index.
        precision: The floating point precision to use for the model.
            - "float32-high" means torch.set_float32_matmul_precision("high") will be called.
            - "float32-highest" means torch.set_float32_matmul_precision("highest") will be called.
            - "float64" means the model will use double precision.
        compile: Whether to torch.compile the model. Defaults to None, which will compile the model
            if the device is not MPS.
        train: Whether to set the model to training mode and keep parameters trainable (except reference energies).
        train_reference_energies: Whether to make reference energies trainable during finetuning.
        loss_weights: Optional dictionary of loss weights to override model defaults.
            Keys should match the loss terms (e.g., "energy", "grad_forces", "forces", "stress", "grad_stress").

    Returns:
        model: The pretrained model
    """
    # Set the precision for the model
    dtype = set_torch_precision(precision)
    model = model.to(dtype)

    # Load the weights
    local_path = cached_path(weights_path)
    state_dict = torch.load(local_path, map_location="cpu", weights_only=True)
    model.load_state_dict(state_dict, strict=True)

    # Move the model to the device
    device = get_device(device)
    model = model.to(device)
    model = model.train(train)

    # Compile the model
    compile = _should_compile(device, compile)
    if compile:
        model.compile(mode="default", dynamic=True)

    # Freeze the parameters
    if not train:
        for param in model.parameters():
            param.requires_grad = False

    # Handle reference energy training
    if hasattr(model, "heads") and "energy" in model.heads:
        if train_reference_energies:
            cast(EnergyHead, model.heads["energy"]).reference.linear.weight.requires_grad = True
        elif train:
            # When training but not training reference energies, explicitly freeze them
            cast(EnergyHead, model.heads["energy"]).reference.linear.weight.requires_grad = False

    # Set loss weights if provided
    if loss_weights is not None and hasattr(model, "loss_weights"):
        model.loss_weights.update(loss_weights)

    return model


def orb_v2_architecture(
    num_message_passing_steps: int = 15,
    device: torch.device | str | None = None,
) -> DirectForcefieldRegressor:
    """Orb-v2 architecture."""
    model = DirectForcefieldRegressor(
        heads={
            "energy": EnergyHead(
                latent_dim=256,
                num_mlp_layers=1,
                mlp_hidden_dim=256,
                predict_atom_avg=True,
                activation="ssp",
            ),
            "forces": ForceHead(
                latent_dim=256,
                num_mlp_layers=1,
                mlp_hidden_dim=256,
                remove_mean=True,
                remove_torque_for_nonpbc_systems=True,
                activation="ssp",
            ),
            "stress": GraphHead(  # type: ignore[dict-item]
                latent_dim=256,
                num_mlp_layers=1,
                mlp_hidden_dim=256,
                target="stress",
                node_aggregation="mean",
                activation="ssp",
            ),
        },
        model=MoleculeGNS(
            num_node_in_features=256,
            num_node_out_features=3,
            num_edge_in_features=23,
            latent_dim=256,
            interaction_params={"distance_cutoff": True, "attention_gate": "sigmoid"},
            num_message_passing_steps=num_message_passing_steps,
            num_mlp_layers=2,
            mlp_hidden_dim=512,
            rbf_transform=partial(gaussian_basis_function, num_bases=20, radius=10.0),
            use_embedding=True,
            node_feature_names=["feat"],
            edge_feature_names=["feat"],
            activation="ssp",
            mlp_norm="layer_norm",
        ),
        pair_repulsion=False,
    )
    device = get_device(device)
    if device is not None and device != torch.device("cpu"):
        model.cuda(device)
    else:
        model = model.cpu()

    return model


def orb_v3_conservative_architecture(
    latent_dim: int = 256,
    base_mlp_hidden_dim: int = 1024,
    base_mlp_depth: int = 2,
    head_mlp_hidden_dim: int = 256,
    head_mlp_depth: int = 1,
    num_message_passing_steps: int = 5,
    activation: str = "silu",
    has_charge_spin_cond: bool = False,
    has_stress: bool = True,
    device: torch.device | str | None = None,
) -> ConservativeForcefieldRegressor:
    """The orb-v3 conservative architecture."""
    if has_charge_spin_cond:
        conditioner = ChargeSpinConditioner(latent_dim)
    else:
        conditioner = None

    model = ConservativeForcefieldRegressor(
        heads={
            "energy": EnergyHead(
                latent_dim=latent_dim,
                num_mlp_layers=head_mlp_depth,
                mlp_hidden_dim=head_mlp_hidden_dim,
                predict_atom_avg=True,
                activation=activation,
            ),
            "confidence": ConfidenceHead(
                latent_dim=latent_dim,
                num_mlp_layers=head_mlp_depth,
                mlp_hidden_dim=head_mlp_hidden_dim,
                activation=activation,
            ),
        },
        model=MoleculeGNS(
            latent_dim=latent_dim,
            num_message_passing_steps=num_message_passing_steps,
            num_mlp_layers=base_mlp_depth,
            mlp_hidden_dim=base_mlp_hidden_dim,
            rbf_transform=BesselBasis(
                r_max=6.0,
                num_bases=8,
            ),
            angular_transform=SphericalHarmonics(
                lmax=3,
                normalize=True,
                normalization="component",
            ),
            outer_product_with_cutoff=True,
            use_embedding=True,
            interaction_params={
                "distance_cutoff": True,
                "attention_gate": "sigmoid",
            },
            node_feature_names=["feat"],
            edge_feature_names=["feat"],
            conditioner=conditioner,
            activation=activation,
            mlp_norm="rms_norm",
        ),
        ensure_grad_loss_weights=False,
        pair_repulsion=True,
        has_stress=has_stress,
    )
    device = get_device(device)
    if device is not None and device != torch.device("cpu"):
        model.cuda(device)
    else:
        model = model.cpu()

    return model


def orb_v3_direct_architecture(
    latent_dim: int = 256,
    base_mlp_hidden_dim: int = 1024,
    base_mlp_depth: int = 2,
    head_mlp_hidden_dim: int = 256,
    head_mlp_depth: int = 1,
    num_message_passing_steps: int = 5,
    activation: str = "silu",
    has_charge_spin_cond: bool = False,
    has_stress: bool = True,
    device: torch.device | str | None = None,
) -> DirectForcefieldRegressor:
    """The orb-v3 architecture, defaulting to a direct model."""
    if has_charge_spin_cond:
        conditioner = ChargeSpinConditioner(latent_dim)
    else:
        conditioner = None

    heads: dict[str, ForcefieldHead | ConfidenceHead] = {
        "energy": EnergyHead(
            latent_dim=latent_dim,
            num_mlp_layers=head_mlp_depth,
            mlp_hidden_dim=head_mlp_hidden_dim,
            predict_atom_avg=True,
            activation=activation,
        ),
        "forces": ForceHead(
            latent_dim=latent_dim,
            num_mlp_layers=head_mlp_depth,
            mlp_hidden_dim=head_mlp_hidden_dim,
            remove_mean=True,
            remove_torque_for_nonpbc_systems=True,
            activation=activation,
        ),
        "confidence": ConfidenceHead(
            latent_dim=latent_dim,
            num_mlp_layers=head_mlp_depth,
            mlp_hidden_dim=head_mlp_hidden_dim,
            activation=activation,
        ),
    }
    if has_stress:
        heads["stress"] = StressHead(
            latent_dim=latent_dim,
            num_mlp_layers=head_mlp_depth,
            mlp_hidden_dim=head_mlp_hidden_dim,
            node_aggregation="mean",
            activation=activation,
        )

    model = DirectForcefieldRegressor(
        heads=heads,
        model=MoleculeGNS(
            latent_dim=latent_dim,
            num_message_passing_steps=num_message_passing_steps,
            num_mlp_layers=base_mlp_depth,
            mlp_hidden_dim=base_mlp_hidden_dim,
            rbf_transform=BesselBasis(
                r_max=6.0,
                num_bases=8,
            ),
            angular_transform=SphericalHarmonics(
                lmax=3,
                normalize=True,
                normalization="component",
            ),
            outer_product_with_cutoff=True,
            use_embedding=True,
            interaction_params={
                "distance_cutoff": True,
                "attention_gate": "sigmoid",
            },
            node_feature_names=["feat"],
            edge_feature_names=["feat"],
            conditioner=conditioner,
            activation=activation,
            mlp_norm="rms_norm",
        ),
        pair_repulsion=True,
    )
    device = get_device(device)
    if device is not None and device != torch.device("cpu"):
        model.cuda(device)
    else:
        model = model.cpu()

    return model


def orb_v3_conservative_omol(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-v3-conservative-omol-20250820.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> tuple[ConservativeForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb v3 Conservative with effectively unlimited neighbors, trained on OMol25.

    'Effectively unlimited' means that the model will use all neighbors within 6A
    the cutoff radius. Empirically, for the training distribution, 120 is sufficient.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    if compile is None and train:
        compile = False
    assert not (train and _should_compile(device, compile)), (
        "Cannot compile a conservative model in training mode."
    )

    # Default to evenly weighted losses
    loss_weights = {
        "energy": 1.0,
        "grad_forces": 1.0,
        "confidence": 1.0,
        **(loss_weights or {}),
    }

    atoms_adapter = ForcefieldAtomsAdapter(
        radius=6.0,
        max_num_neighbors=120,
        extra_features={"graph": ["total_charge", "spin_multiplicity"]},
    )
    model = orb_v3_conservative_architecture(
        device=device,
        has_charge_spin_cond=True,
        has_stress=True,
    )
    model = load_model(
        model,
        weights_path,
        device,
        precision=precision,
        compile=compile,
        train=train,
        train_reference_energies=train_reference_energies,
        loss_weights=loss_weights,
    )

    return model, atoms_adapter


def orb_v3_direct_omol(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-v3-direct-omol-20250820.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> tuple[DirectForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb v3 Direct with effectively unlimited neighbors, trained on OMol25.

    'Effectively unlimited' means that the model will use all neighbors within 6A
    the cutoff radius. Empirically, for the training distribution, 120 is sufficient.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    # Default to evenly weighted losses
    loss_weights = {
        "energy": 1.0,
        "forces": 1.0,
        "confidence": 1.0,
        **(loss_weights or {}),
    }

    atoms_adapter = ForcefieldAtomsAdapter(
        radius=6.0,
        max_num_neighbors=120,
        extra_features={"graph": ["total_charge", "spin_multiplicity"]},
    )
    model = orb_v3_direct_architecture(
        device=device,
        has_charge_spin_cond=True,
        has_stress=False,
    )
    model = load_model(
        model,
        weights_path,
        device,
        precision=precision,
        compile=compile,
        train=train,
        train_reference_energies=train_reference_energies,
        loss_weights=loss_weights,
    )

    return model, atoms_adapter


def orb_v3_conservative_20_omat(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-v3/orb-v3-conservative-20-omat-20250404.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> tuple[ConservativeForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb v3 Conservative 20 max neighbors OMAT.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    if compile is None and train:
        compile = False
    assert not (train and _should_compile(device, compile)), (
        "Cannot compile a conservative model in training mode."
    )

    # Default to evenly weighted losses
    loss_weights = {
        "energy": 1.0,
        "grad_forces": 1.0,
        "grad_stress": 1.0,
        "confidence": 1.0,
        **(loss_weights or {}),
    }

    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=20)
    model = orb_v3_conservative_architecture(device=device)
    model = load_model(
        model,
        weights_path,
        device,
        precision=precision,
        compile=compile,
        train=train,
        train_reference_energies=train_reference_energies,
        loss_weights=loss_weights,
    )

    return model, atoms_adapter


def orb_v3_conservative_inf_omat(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-v3/orb-v3-conservative-inf-omat-20250404.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> tuple[ConservativeForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb v3 Conservative with effectively unlimited neighbors, trained on OMAT.

    'Effectively unlimited' means that the model will use all neighbors within 6A
    the cutoff radius. Empirically, for the training distribution, 120 is sufficient.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    if compile is None and train:
        compile = False
    assert not (train and _should_compile(device, compile)), (
        "Cannot compile a conservative model in training mode."
    )

    # Default to evenly weighted losses
    loss_weights = {
        "energy": 1.0,
        "grad_forces": 1.0,
        "grad_stress": 1.0,
        "confidence": 1.0,
        **(loss_weights or {}),
    }

    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=120)
    model = orb_v3_conservative_architecture(device=device)
    model = load_model(
        model,
        weights_path,
        device,
        precision=precision,
        compile=compile,
        train=train,
        train_reference_energies=train_reference_energies,
        loss_weights=loss_weights,
    )

    return model, atoms_adapter


def orb_v3_direct_20_omat(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-v3/orb-v3-direct-20-omat-20250404.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> tuple[DirectForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb v3 Direct 20 max neighbors OMAT.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    # Default to evenly weighted losses
    loss_weights = {
        "energy": 1.0,
        "forces": 1.0,
        "stress": 1.0,
        "confidence": 1.0,
        **(loss_weights or {}),
    }

    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=20)
    model = orb_v3_direct_architecture(device=device)
    model = load_model(
        model,
        weights_path,
        device,
        precision=precision,
        compile=compile,
        train=train,
        train_reference_energies=train_reference_energies,
        loss_weights=loss_weights,
    )

    return model, atoms_adapter


def orb_v3_direct_inf_omat(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-v3/orb-v3-direct-inf-omat-20250404.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> tuple[DirectForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb v3 Direct with effectively unlimited neighbors, trained on OMAT.

    'Effectively unlimited' means that the model will use all neighbors within 6A
    the cutoff radius. Empirically, for the training distribution, 120 is sufficient.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    # Default to evenly weighted losses
    loss_weights = {
        "energy": 1.0,
        "forces": 1.0,
        "stress": 1.0,
        "confidence": 1.0,
        **(loss_weights or {}),
    }

    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=120)
    model = orb_v3_direct_architecture(device=device)
    model = load_model(
        model,
        weights_path,
        device,
        precision=precision,
        compile=compile,
        train=train,
        train_reference_energies=train_reference_energies,
        loss_weights=loss_weights,
    )

    return model, atoms_adapter


def orb_v3_conservative_20_mpa(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-v3/orb-v3-conservative-20-mpa-20250404.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> tuple[ConservativeForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb v3 Conservative 20 max neighbors MPTraj + Alexandria.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    if compile is None and train:
        compile = False
    assert not (train and _should_compile(device, compile)), (
        "Cannot compile a conservative model in training mode."
    )

    # Default to evenly weighted losses
    loss_weights = {
        "energy": 1.0,
        "grad_forces": 1.0,
        "grad_stress": 1.0,
        "confidence": 1.0,
        **(loss_weights or {}),
    }

    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=20)
    model = orb_v3_conservative_architecture(device=device)
    model = load_model(
        model,
        weights_path,
        device,
        precision=precision,
        compile=compile,
        train=train,
        train_reference_energies=train_reference_energies,
        loss_weights=loss_weights,
    )

    return model, atoms_adapter


def orb_v3_conservative_inf_mpa(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-v3/orb-v3-conservative-inf-mpa-20250404.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> tuple[ConservativeForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb v3 Conservative with effectively unlimited neighbors, trained on MPTraj + Alexandria.

    'Effectively unlimited' means that the model will use all neighbors within 6A
    the cutoff radius. Empirically, for the training distribution, 120 is sufficient.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    if compile is None and train:
        compile = False
    assert not (train and _should_compile(device, compile)), (
        "Cannot compile a conservative model in training mode."
    )

    # Default to evenly weighted losses
    loss_weights = {
        "energy": 1.0,
        "grad_forces": 1.0,
        "grad_stress": 1.0,
        "confidence": 1.0,
        **(loss_weights or {}),
    }

    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=120)
    model = orb_v3_conservative_architecture(device=device)
    model = load_model(
        model,
        weights_path,
        device,
        precision=precision,
        compile=compile,
        train=train,
        train_reference_energies=train_reference_energies,
        loss_weights=loss_weights,
    )

    return model, atoms_adapter


def orb_v3_direct_20_mpa(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-v3/orb-v3-direct-20-mpa-20250404.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> tuple[DirectForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb v3 Direct 20 max neighbors MPTraj + Alexandria.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    # Default to evenly weighted losses
    loss_weights = {
        "energy": 1.0,
        "forces": 1.0,
        "stress": 1.0,
        "confidence": 1.0,
        **(loss_weights or {}),
    }

    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=20)
    model = orb_v3_direct_architecture(device=device)
    model = load_model(
        model,
        weights_path,
        device,
        precision=precision,
        compile=compile,
        train=train,
        train_reference_energies=train_reference_energies,
        loss_weights=loss_weights,
    )

    return model, atoms_adapter


def orb_v3_direct_inf_mpa(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-v3/orb-v3-direct-inf-mpa-20250404.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> tuple[DirectForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb v3 Direct with effectively unlimited neighbors, trained on MPTraj + Alexandria.

    'Effectively unlimited' means that the model will use all neighbors within 6A
    the cutoff radius. Empirically, for the training distribution, 120 is sufficient.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    # Default to evenly weighted losses
    loss_weights = {
        "energy": 1.0,
        "forces": 1.0,
        "stress": 1.0,
        "confidence": 1.0,
        **(loss_weights or {}),
    }

    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=120)
    model = orb_v3_direct_architecture(device=device)
    model = load_model(
        model,
        weights_path,
        device,
        precision=precision,
        compile=compile,
        train=train,
        train_reference_energies=train_reference_energies,
        loss_weights=loss_weights,
    )

    return model, atoms_adapter


def separate_d3_direct_3layer(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/separate-d3-3layer.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
) -> tuple[DirectForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load a separate D3 direct model.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=120)
    model = orb_v3_direct_architecture(num_message_passing_steps=3, device=device)
    model = load_model(
        model, weights_path, device, precision=precision, compile=compile, train=train
    )
    return model, atoms_adapter


def separate_d3_direct_5layer(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/separate-d3-5layer.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
) -> tuple[DirectForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load a separate D3 direct model.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=120)
    model = orb_v3_direct_architecture(device=device)
    model = load_model(
        model, weights_path, device, precision=precision, compile=compile, train=train
    )
    return model, atoms_adapter


def separate_d4_direct_3layer(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/separate-d4-3layer.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
) -> tuple[DirectForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load a separate D4 direct model.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=120)
    model = orb_v3_direct_architecture(num_message_passing_steps=3, device=device)
    model = load_model(
        model, weights_path, device, precision=precision, compile=compile, train=train
    )
    return model, atoms_adapter


def separate_d4_direct_5layer(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/separate-d4-5layer.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
) -> tuple[DirectForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load a separate D4 direct model.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=120)
    model = orb_v3_direct_architecture(device=device)
    model = load_model(
        model, weights_path, device, precision=precision, compile=compile, train=train
    )
    return model, atoms_adapter


def orb_v2(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-v2-20241011.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> tuple[DirectForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb v2 Direct with 20 max neighbors, trained on MPTraj + Alexandria.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    # Default to evenly weighted losses
    loss_weights = {
        "energy": 1.0,
        "forces": 1.0,
        "stress": 1.0,
        **(loss_weights or {}),
    }

    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=20)
    model = orb_v2_architecture(device=device)
    model = load_model(
        model,
        weights_path,
        device,
        precision=precision,
        compile=compile,
        train=train,
        train_reference_energies=train_reference_energies,
        loss_weights=loss_weights,
    )

    return model, atoms_adapter


def orb_mptraj_only_v2(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-mptraj-only-v2-20241014.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
    train_reference_energies: bool = False,
    loss_weights: dict[str, float] | None = None,
) -> tuple[DirectForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb MPTraj Only v2 Direct with 20 max neighbors, trained on MPTraj.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    # Default to evenly weighted losses
    loss_weights = {
        "energy": 1.0,
        "forces": 1.0,
        "stress": 1.0,
        **(loss_weights or {}),
    }

    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=20)
    model = orb_v2_architecture(device=device)
    model = load_model(
        model,
        weights_path,
        device,
        precision=precision,
        compile=compile,
        train=train,
        train_reference_energies=train_reference_energies,
        loss_weights=loss_weights,
    )

    return model, atoms_adapter


def orb_d3_v2(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-d3-v2-20241011.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
) -> tuple[DirectForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb D3 v2 Direct with 20 max neighbors, trained on MPTraj + Alexandria."""
    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=20)
    model = orb_v2_architecture(device=device)
    model = load_model(
        model, weights_path, device, precision=precision, compile=compile, train=train
    )

    return model, atoms_adapter


def orb_d3_sm_v2(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-d3-sm-v2-20241011.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
) -> tuple[DirectForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb D3 small v2 with 20 max neighbors, trained on MPTraj + Alexandria.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=20)
    model = orb_v2_architecture(num_message_passing_steps=10, device=device)
    model = load_model(
        model, weights_path, device, precision=precision, compile=compile, train=train
    )

    return model, atoms_adapter


def orb_d3_xs_v2(
    weights_path: str = "https://orbitalmaterials-public-models.s3.us-west-1.amazonaws.com/forcefields/orb-d3-xs-v2-20241011.ckpt",  # noqa: E501
    device: torch.device | str | None = None,
    precision: str = "float32-high",
    compile: bool | None = None,
    train: bool = False,
) -> tuple[DirectForcefieldRegressor, ForcefieldAtomsAdapter]:
    """Load Orb D3 xs v2 with 20 max neighbors, trained on MPTraj + Alexandria.

    Returns:
        - model: The loaded model.
        - atoms_adapter: The atoms adapter used during training.
    """
    atoms_adapter = ForcefieldAtomsAdapter(radius=6.0, max_num_neighbors=20)
    model = orb_v2_architecture(num_message_passing_steps=5, device=device)
    model = load_model(
        model, weights_path, device, precision=precision, compile=compile, train=train
    )

    return model, atoms_adapter


def _deprecated_model(model_name: str):
    """Deprecated model."""

    raise ValueError(
        f"{model_name} is deprecated. Please use orb-v2 instead."
        "Orb V2 models are more accurate, more robust under simulation, and run faster."
    )


def orb_v1(
    weights_path: str | None = None,
    device: torch.device | str | None = None,
):
    """Deprecated model."""

    _deprecated_model("orb-v1")


def orb_d3_v1(
    weights_path: str | None = None,
    device: torch.device | str | None = None,
):
    """Deprecated model."""

    _deprecated_model("orb-d3-v1")


def orb_d3_sm_v1(
    weights_path: str | None = None,
    device: torch.device | str | None = None,
):
    """Deprecated model."""

    _deprecated_model("orb-d3-sm-v1")


def orb_d3_xs_v1(
    weights_path: str | None = None,
    device: torch.device | str | None = None,
):
    """Deprecated model."""
    _deprecated_model("orb-d3-xs-v1")


def orb_v1_mptraj_only(
    weights_path: str | None = None,
    device: torch.device | str | None = None,
):
    """Deprecated model."""
    _deprecated_model("orb-mptraj-only-v1")


ORB_PRETRAINED_MODELS = {
    # orb-v3 omol models
    "orb-v3-conservative-omol": orb_v3_conservative_omol,
    "orb-v3-direct-omol": orb_v3_direct_omol,
    # most performant orb-v3 omat models
    "orb-v3-conservative-20-omat": orb_v3_conservative_20_omat,
    "orb-v3-conservative-inf-omat": orb_v3_conservative_inf_omat,
    "orb-v3-direct-20-omat": orb_v3_direct_20_omat,
    "orb-v3-direct-inf-omat": orb_v3_direct_inf_omat,
    # less performant orb-v3 mptraj + alexandria models
    "orb-v3-conservative-20-mpa": orb_v3_conservative_20_mpa,
    "orb-v3-conservative-inf-mpa": orb_v3_conservative_inf_mpa,
    "orb-v3-direct-20-mpa": orb_v3_direct_20_mpa,
    "orb-v3-direct-inf-mpa": orb_v3_direct_inf_mpa,
    # separate d3 and d4 models
    "separate-d3-3layer": separate_d3_direct_3layer,
    "separate-d3-5layer": separate_d3_direct_5layer,
    "separate-d4-3layer": separate_d4_direct_3layer,
    "separate-d4-5layer": separate_d4_direct_5layer,
    # less performant orb-v2 models
    "orb-v2": orb_v2,
    "orb-d3-v2": orb_d3_v2,
    "orb-d3-sm-v2": orb_d3_sm_v2,
    "orb-d3-xs-v2": orb_d3_xs_v2,
    "orb-mptraj-only-v2": orb_mptraj_only_v2,
    # Deprecated models
    "orb-v1": orb_v1,
    "orb-d3-v1": orb_d3_v1,
    "orb-d3-sm-v1": orb_d3_sm_v1,
    "orb-d3-xs-v1": orb_d3_xs_v1,
    "orb-v1-mptraj-only": orb_v1_mptraj_only,
}
